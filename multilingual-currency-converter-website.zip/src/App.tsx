import { FormEvent, useEffect, useMemo, useState } from "react";

type Language = "en" | "es" | "fr";

type CurrencyMap = Record<string, string>;

const copy: Record<Language, Record<string, string>> = {
  en: {
    brand: "GlobalFX",
    title: "Currency Converter",
    subtitle: "Convert live exchange rates in seconds.",
    amount: "Amount",
    from: "From",
    to: "To",
    convert: "Convert",
    result: "Converted Amount",
    loading: "Loading currencies...",
    converting: "Converting...",
    fetchError: "Unable to fetch exchange rates right now.",
    footer: "Built with HTML, CSS, and JavaScript.",
    updated: "Last updated",
  },
  es: {
    brand: "GlobalFX",
    title: "Convertidor de Monedas",
    subtitle: "Convierte tipos de cambio en vivo en segundos.",
    amount: "Cantidad",
    from: "Desde",
    to: "Hacia",
    convert: "Convertir",
    result: "Cantidad Convertida",
    loading: "Cargando monedas...",
    converting: "Convirtiendo...",
    fetchError: "No se pueden obtener los tipos de cambio ahora.",
    footer: "Hecho con HTML, CSS y JavaScript.",
    updated: "Ultima actualizacion",
  },
  fr: {
    brand: "GlobalFX",
    title: "Convertisseur de Devises",
    subtitle: "Convertissez les taux de change en direct en quelques secondes.",
    amount: "Montant",
    from: "De",
    to: "Vers",
    convert: "Convertir",
    result: "Montant Converti",
    loading: "Chargement des devises...",
    converting: "Conversion en cours...",
    fetchError: "Impossible de recuperer les taux de change maintenant.",
    footer: "Cree avec HTML, CSS et JavaScript.",
    updated: "Derniere mise a jour",
  },
};

export default function App() {
  const [language, setLanguage] = useState<Language>("en");
  const [currencies, setCurrencies] = useState<CurrencyMap>({});
  const [amount, setAmount] = useState<string>("1");
  const [fromCurrency, setFromCurrency] = useState<string>("USD");
  const [toCurrency, setToCurrency] = useState<string>("EUR");
  const [result, setResult] = useState<number | null>(null);
  const [updatedAt, setUpdatedAt] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isConverting, setIsConverting] = useState<boolean>(false);
  const [isSwapping, setIsSwapping] = useState<boolean>(false);
  const [error, setError] = useState<string>("");

  const text = copy[language];

  const currencyOptions = useMemo(
    () =>
      Object.entries(currencies).sort((a, b) =>
        a[0].localeCompare(b[0], "en", { sensitivity: "base" })
      ),
    [currencies]
  );

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        setIsLoading(true);
        setError("");

        const [currenciesRes, ratesRes] = await Promise.all([
          fetch("https://api.frankfurter.app/currencies"),
          fetch("https://api.frankfurter.app/latest?amount=1&from=USD&to=EUR"),
        ]);

        if (!currenciesRes.ok || !ratesRes.ok) {
          throw new Error("Failed to load data");
        }

        const currenciesData = (await currenciesRes.json()) as CurrencyMap;
        const ratesData = (await ratesRes.json()) as {
          date: string;
          rates: Record<string, number>;
        };

        setCurrencies(currenciesData);
        setUpdatedAt(ratesData.date);
        setResult(ratesData.rates.EUR);

        if (!currenciesData[fromCurrency]) {
          setFromCurrency(Object.keys(currenciesData)[0] ?? "USD");
        }

        if (!currenciesData[toCurrency]) {
          setToCurrency(Object.keys(currenciesData)[1] ?? "EUR");
        }
      } catch {
        setError(text.fetchError);
      } finally {
        setIsLoading(false);
      }
    };

    void loadInitialData();
  }, []);

  useEffect(() => {
    if (!error) {
      return;
    }

    setError(text.fetchError);
  }, [language]);

  const handleConvert = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const numericAmount = Number(amount);

    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      setResult(null);
      return;
    }

    try {
      setIsConverting(true);
      setError("");

      const url = `https://api.frankfurter.app/latest?amount=${numericAmount}&from=${fromCurrency}&to=${toCurrency}`;
      const response = await fetch(url);

      if (!response.ok) {
        throw new Error("Conversion failed");
      }

      const data = (await response.json()) as {
        date: string;
        rates: Record<string, number>;
      };

      setUpdatedAt(data.date);
      setResult(data.rates[toCurrency] ?? null);
    } catch {
      setError(text.fetchError);
    } finally {
      setIsConverting(false);
    }
  };

  const swapCurrencies = () => {
    setIsSwapping(true);
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);

    window.setTimeout(() => {
      setIsSwapping(false);
    }, 350);
  };

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 hero-bg-motion">
      <section className="mx-auto flex min-h-screen w-full max-w-6xl items-center px-5 py-10 sm:px-8 lg:px-12">
        <div className="w-full animate-fade-up">
          <div className="mb-8 flex items-center justify-between gap-4">
            <div>
              <p className="text-2xl font-semibold tracking-tight text-white">{text.brand}</p>
              <p className="text-sm text-slate-300">{text.subtitle}</p>
            </div>

            <label className="flex items-center gap-2 text-sm text-slate-200">
              <span>Language</span>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-sm outline-none transition focus:border-indigo-400"
              >
                <option value="en">English</option>
                <option value="es">Espanol</option>
                <option value="fr">Francais</option>
              </select>
            </label>
          </div>

          <h1 className="mb-6 text-4xl font-bold tracking-tight text-white sm:text-5xl">{text.title}</h1>

          <form
            onSubmit={handleConvert}
            className="grid gap-4 rounded-2xl border border-slate-800 bg-slate-900/70 p-5 backdrop-blur sm:grid-cols-[1fr_220px_56px_220px_auto] sm:items-end"
          >
            <label className="block">
              <span className="mb-2 block text-sm text-slate-300">{text.amount}</span>
              <input
                type="number"
                min="0"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-white outline-none transition focus:border-indigo-400"
              />
            </label>

            <label className="block">
              <span className="mb-2 block text-sm text-slate-300">{text.from}</span>
              <select
                value={fromCurrency}
                onChange={(e) => setFromCurrency(e.target.value)}
                className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-white outline-none transition focus:border-indigo-400"
              >
                {currencyOptions.map(([code, name]) => (
                  <option key={code} value={code}>
                    {code} - {name}
                  </option>
                ))}
              </select>
            </label>

            <button
              type="button"
              onClick={swapCurrencies}
              className="inline-flex h-11 w-11 items-center justify-center self-center rounded-md border border-slate-700 bg-slate-950 text-slate-200 transition hover:border-indigo-400"
              aria-label="Swap currencies"
            >
              <svg
                className={`h-5 w-5 ${isSwapping ? "swap-spin" : ""}`}
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M7 7h11l-3-3" />
                <path d="M17 17H6l3 3" />
              </svg>
            </button>

            <label className="block">
              <span className="mb-2 block text-sm text-slate-300">{text.to}</span>
              <select
                value={toCurrency}
                onChange={(e) => setToCurrency(e.target.value)}
                className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-white outline-none transition focus:border-indigo-400"
              >
                {currencyOptions.map(([code, name]) => (
                  <option key={code} value={code}>
                    {code} - {name}
                  </option>
                ))}
              </select>
            </label>

            <button
              type="submit"
              disabled={isLoading || isConverting}
              className="h-11 rounded-md bg-indigo-500 px-4 font-medium text-white transition hover:bg-indigo-400 disabled:cursor-not-allowed disabled:bg-indigo-500/50"
            >
              {isConverting ? text.converting : text.convert}
            </button>
          </form>

          <div className="mt-6 min-h-16">
            {isLoading ? <p className="text-slate-300">{text.loading}</p> : null}
            {error ? <p className="text-red-300">{error}</p> : null}

            {!isLoading && !error && result !== null ? (
              <div className="animate-soft-pop">
                <p className="text-sm text-slate-400">{text.result}</p>
                <p className="text-3xl font-semibold text-white sm:text-4xl">
                  {result.toLocaleString(undefined, {
                    maximumFractionDigits: 4,
                  })}{" "}
                  {toCurrency}
                </p>
                {updatedAt ? (
                  <p className="mt-1 text-sm text-slate-400">
                    {text.updated}: {updatedAt}
                  </p>
                ) : null}
              </div>
            ) : null}
          </div>

          <p className="mt-10 text-xs text-slate-500">{text.footer}</p>
        </div>
      </section>
    </main>
  );
}
